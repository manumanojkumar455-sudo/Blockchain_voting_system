import hashlib
import json


# Block class
class Block:
    def __init__(self, index, data, previous_hash):
        self.index = index
        self.data = data
        self.previous_hash = previous_hash
        self.hash = self.calculate_hash()

    # Generate SHA-256 hash
    def calculate_hash(self):
        block_data = json.dumps({
            "index": self.index,
            "data": self.data,
            "previous_hash": self.previous_hash
        }, sort_keys=True)

        return hashlib.sha256(block_data.encode()).hexdigest()


# Blockchain class
class Blockchain:
    def __init__(self):
        self.chain = []

        # Create the first block
        self.add_block("Genesis Block")

    # Add a new block
    def add_block(self, data):
        if len(self.chain) == 0:
            previous_hash = "0"
        else:
            previous_hash = self.chain[-1].hash

        new_block = Block(
            len(self.chain),
            data,
            previous_hash
        )

        self.chain.append(new_block)

    # Display all blocks
    def display_chain(self):
        for block in self.chain:
            print("\n----------------------------")
            print("Block Number:", block.index)
            print("Data:", block.data)
            print("Previous Hash:", block.previous_hash)
            print("Current Hash:", block.hash)
            print("----------------------------")

    # Verify blockchain integrity
    def is_chain_valid(self):
        for i in range(len(self.chain)):
            current_block = self.chain[i]

            # Check current block hash
            if current_block.hash != current_block.calculate_hash():
                return False

            # Check connection to previous block
            if i > 0:
                previous_block = self.chain[i - 1]

                if current_block.previous_hash != previous_block.hash:
                    return False

        return True


# Main program
if __name__ == "__main__":

    # Create blockchain
    voting_blockchain = Blockchain()

    # Add sample votes
    voting_blockchain.add_block({
        "voter": "V001",
        "candidate": "Candidate A"
    })

    voting_blockchain.add_block({
        "voter": "V002",
        "candidate": "Candidate B"
    })

    voting_blockchain.add_block({
        "voter": "V003",
        "candidate": "Candidate A"
    })

    # Display blockchain
    print("\n===== BLOCKCHAIN VOTING SYSTEM =====")

    voting_blockchain.display_chain()

    # Verify original blockchain
    print("\n===== BLOCKCHAIN VERIFICATION =====")

    print(
        "Is blockchain valid?",
        voting_blockchain.is_chain_valid()
    )

    # Simulate tampering with a vote
    print("\n===== TAMPERING TEST =====")

    voting_blockchain.chain[1].data = {
        "voter": "V001",
        "candidate": "Candidate B"
    }

    print(
        "Is blockchain valid after tampering?",
        voting_blockchain.is_chain_valid()
    )